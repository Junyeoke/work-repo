import React from 'react'

function Home() {
  return (
    <div className='container mt-5'>
        <h3>
            회원정보조회 사이트에 오신것을 환영합니다.
        </h3>
    </div>
  )
}

export default Home