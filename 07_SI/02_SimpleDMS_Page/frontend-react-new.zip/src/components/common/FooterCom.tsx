﻿import React from 'react'

function FooterCom() {
  return (
    <div>FooterCom</div>
  )
}

export default FooterCom