// ICinemaFaq.ts : 타입 인터페이스
export default interface ICinemaFaq {         
  cfno?: any | null,
  question: string,
  answer: string,
  sortOrder: number | string,
}