export default interface IFaq {
  no?: any | null;
  title: string;
  content: string;
}
