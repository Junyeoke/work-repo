package com.example.playhostproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlayhostProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
