
export { default as CKEditor } from './ckeditor';