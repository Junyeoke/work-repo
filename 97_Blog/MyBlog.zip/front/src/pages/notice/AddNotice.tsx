import React from 'react'

function AddNotice() {
  return (
    <div>AddNotice</div>
  )
}

export default AddNotice