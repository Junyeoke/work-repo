import React, { useState } from "react";
import TitleCom from "../../components/common/TitleCom";
import Notice from "../../types/Notice";
import NoticeService from "../../services/NoticeService";
import { CKEditor } from "@ckeditor/ckeditor5-react";
import ClassicEditor from "@ckeditor/ckeditor5-build-classic";

function AddNotice() {
  // 객체 초기화
  const initialNotice = {
    num: null,
    title: "",
    userName: "",
    content: "",
  };

  // 공지 객체
  const [notice, setNotice] = useState<Notice>(initialNotice);
  // 저장버튼 클릭 후 submitted = true 변경됨
  const [submitted, setSubmitted] = useState<boolean>(false);

  // input 태그에 수동 바인딩 함수
  const handleInputChange = (event: any) => {
    const { name, value } = event.target; // 화면값
    setNotice({ ...notice, [name]: value }); // 변수저장
  };

  // 저장 함수
  const saveNotice = () => {
    // 임시 부서 객체
    var data = {
      title: notice.title,
      userName: notice.userName,
      content: notice.content,
    };

    NoticeService.create(data) // 저장 요청
      .then((response: any) => {
        setSubmitted(true);
        console.log(response.data);
      })
      .catch((e: Error) => {
        console.log(e);
      });
  };

  // 새 폼 보여주기 함수 : 변수값 변경 -> 화면 자동 갱신(리액트 특징)
  const newNotice = () => {
    setNotice(initialNotice); // 부서 초기화
    setSubmitted(false); // submitted 변수 초기화
  };
  return (
    <div className="container ">
      {submitted ? (
        <div className="col-6 mx-auto">
          <h4>You submitted successfully!</h4>
          <button className="btn btn-success" onClick={newNotice}>
            글쓰기
          </button>
        </div>
      ) : (
        <>
          {/* 제목 start */}
          <TitleCom title="공지사항 작성" />
          {/* 제목 end */}
          <label htmlFor="title" className="col-form-label">
            제목
          </label>
          <input
            type="text"
            id="boardTitle"
            required
            className="form-control mb-3"
            value={notice.title}
            onChange={handleInputChange}
            placeholder="글제목"
            name="title"
          />
          <label htmlFor="userName" className="col-form-label ">
            작성자
          </label>
          <input
            type="text"
            id="userName"
            required
            className="form-control mb-4"
            value={notice.userName}
            onChange={handleInputChange}
            placeholder="작성자명"
            name="userName"
          />
          <div className="editor">
          <CKEditor
            editor={ClassicEditor}
            
            onReady={(editor) => {
              // You can store the "editor" and use when it is needed.
              console.log("Editor is ready to use!", editor);
            }}
            onChange={(event, editor) => {
              const data = editor.getData();
              
              
              console.log({ event, editor, data });
            }}
            onBlur={(event, editor) => {
              console.log("Blur.", editor);
            }}
            onFocus={(event, editor) => {
              console.log("Focus.", editor);
            }}
          />
          </div>

          <div className="form-row float-end mt-3">
            <button
              onClick={saveNotice}
              className="btn btn-outline-dark"
            >
              글쓰기
            </button>
          </div>
        </>
      )}
    </div>
  );
}

export default AddNotice;
