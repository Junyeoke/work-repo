﻿import React, { useEffect } from "react";
import TitleCom from "../components/common/TitleCom";
import initWow from "../assets/js/mywow";
import { Link } from "react-router-dom";

function Home() {
  useEffect(() => {
    initWow();
  });
  return (
    <>
      {/* 제목 start */}
      {/* <TitleCom title="Home" /> */}
      {/* 제목 end */}

      <div id="content-wrapper">
        <p className="fs-3 wow flipInX">
          안녕하세요 준혁's IT Blog 입니다. <br />
          최신 IT 소식과 IT 기기 리뷰 정보를 제공하는 사이트입니다. <br />
        </p>
        {/* <!-- 로고 아이콘 저작권 표시 --> */}
        <a
          href="https://www.flaticon.com/kr/free-icons/it-"
          title="it 부서 아이콘"
        >
          It 부서 아이콘 제작자: rukanicon - Flaticon
        </a>
      </div>

      {/* <!-- Heading Row--> */}
      <div className="row gx-4 gx-lg-5 align-items-center my-5">
        <div className="col-lg-7">
          <img
            className="img-fluid rounded mb-4 mb-lg-0"
            src="https://dummyimage.com/900x400/dee2e6/6c757d.jpg"
            alt="..."
          />
        </div>
        <div className="col-lg-5">
          <h1 className="font-weight-light">인기글 테스트</h1>
          <p>인기글 내용을 보여주는 부분</p>
          <a className="btn btn-primary" href="#!">
            게시글 보러가기!
          </a>
        </div>
      </div>
      {/* <!-- Call to Action--> */}
      <div className="card text-white bg-secondary my-5 py-4 text-center">
        <div className="card-body">
          <p className="text-white m-0">
            최신 IT 소식들을 블로그에서 만나보세요!
          </p>
        </div>
      </div>
      {/* <!-- Content Row--> */}
      <div className="row gx-4 gx-lg-5">
        <div className="col-md-4 mb-5">
          <div className="card h-100">
            <div className="card-body">
              <h2 className="card-title">공지사항</h2>
              <p className="card-text">공지사항 내용을 보여주는 곳입니다.</p>
            </div>
            <div className="card-footer">
              <Link to="/notice" className="btn btn-primary btn-sm">
                자세히 보기
              </Link>
            </div>
          </div>
        </div>
        <div className="col-md-4 mb-5">
          <div className="card h-100">
            <div className="card-body">
              <h2 className="card-title">IT 소식</h2>
              <p className="card-text">IT 소식을 보여주는 부분입니다.</p>
            </div>
            <div className="card-footer">
              <Link to="/news" className="btn btn-primary btn-sm">
                자세히 보기
              </Link>
            </div>
          </div>
        </div>
        <div className="col-md-4 mb-5">
          <div className="card h-100">
            <div className="card-body">
              <h2 className="card-title">IT 기기 리뷰</h2>
              <p className="card-text">리뷰 내용을 보여주는 부분입니다.</p>
            </div>
            <div className="card-footer">
              <Link to="/review" className="btn btn-primary btn-sm">
                자세히 보기
              </Link>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Home;
