export default interface Notice{
    num?: any | null;
    title: string,
    userName: string,
    content: string,
}