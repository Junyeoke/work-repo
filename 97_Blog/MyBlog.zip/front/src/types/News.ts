export default interface News {
  no?: any | null,
  title: string,
  userName: string,
  content: string,
  viewCnt: number,
  insertTime?: string | null
}
