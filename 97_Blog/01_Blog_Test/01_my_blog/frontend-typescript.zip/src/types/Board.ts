export default interface Board{
    no?: any | null;
    title: string,
    userName: string,
    content: string,
    viewCnt: number,
    insertTime?: string | null
}