export default interface Notice{
    id?: any | null;
    title: string,
    userName: string,
    content: string,
    insertTime?: string | null
}